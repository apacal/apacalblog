<?php

$dir = 'Upload';
del_dir($dir);
/**
 * 递归删除目录下的文件
 */
function delTree($dir) { 
    $files = array_diff(scandir($dir), array('.','..')); 
    foreach ($files as $file) { 
        (is_dir("$dir/$file")) ? delTree("$dir/$file") : unlink("$dir/$file"); 
    } 
    rmdir($dir); 
} 

/**
 * 系统调用
 **/
function del_dir($dir) {
    if(strtoupper(substr(PHP_OS, 0, 3)) == 'WIN') {   
            $str = "rmdir /s/q ".$dir;   
    }else{   
            $str = "rm -fr ".$dir;   
    }   
    $line = system($str, $result);
    if($line)
        echo $result;
}
