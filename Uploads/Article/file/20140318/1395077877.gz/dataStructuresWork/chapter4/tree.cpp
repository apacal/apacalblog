#include<iostream>
using namespace std;

struct TreeNode {
    string data;
    TreeNode * firstChild;
    TreeNode * nextSibling;
    TreeNode(string s, TreeNode * f = NULL, TreeNode * n = NULL) 
        : data(s), firstChild(f), nextSibling(n) {}
    
};
int main() {
    return 0;
}
