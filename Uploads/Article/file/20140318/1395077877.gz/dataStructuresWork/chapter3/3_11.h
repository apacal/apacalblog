/*
单向链表类
没有尾节点，只有头节点
*/
template <typename Object>
class singleList {
    private:
        struct Node {
            Object data;
            Node *next;
            Node(const Object & d = Object(), Node * n = NULL)
                : data(d), next(n) {}
        };
    public:
        singleList() {
            init();
        }

        ~singleList() {
            eraseList(head);
        }

        singleList(const singleList & rhs) {
            eraseList(head);
            init();
            * this = rhs;
        }

        void init() {
            theSize = 0;
            head = new Node<Object>;
            head -> next = NULL;
        }

        void eraseList(Node<Object> * head) {
            Node<Object> * p = head;
            Node<Object> * next;
            while(p != NULL) {
                next = p->next;
                delete p;
                p = next;
            }
        }

        /*
            判断x是否在List中，在就删除，不在就添加
            @param Object x
        */
        void isData(x) {
            if(_isData(x)) {
                Node<Object> * p = head->next;
                Node<Object> * next;
                while(p->data != x) {
                    next = p;
                    p = next->next;
                }
                next->next = p->next;
                delete p;
                theSize--;
                cout<< x << "in List" << "and delete it from List" <<endl;
            }else{
                Node<Object> * p = new Node<Object>(x);
                p->next = head->next;
                head->next = p;
                theSize++;
                cout<< x << "not in List" << "and put it in List" <<endl;
            }
        }

        /* 判断List中是否存在x  
           @param cosnt Object & x
        */
        bool _isData(const Object & x) {
            Node<Object> * p = head->next;
            while(p != NULL) {
                if(x == p->data)
                    return true;
                else 
                    p = p->next;
            }
            return false;
        }

        int size() {
            return theSize;
        }

        void print() {
            Node<Object> *p = head->next;
            while(p != NULL) {
                cout << p->data << " ";
                p = p->next;
            }
            cout <<  endl;
        }

    private:
        int theSize;
        Node *head;


};

