#include<iostream>
#include <cstdlib>

using namespace std;

#include "evalPostFix.h"

int main() {
    cout << "11" << endl;
    cout << evalPostFix() << endl;
    return 0;
}
