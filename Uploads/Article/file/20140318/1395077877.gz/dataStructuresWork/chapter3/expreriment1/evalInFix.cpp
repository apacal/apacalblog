/*
    计算中缀表达式的值
    1.inFixToPostFix 函数处理输入的是否是数字还是运算符，并压如对应的堆栈中。
    2.evalPostFix计算后缀表达式，当符合规则时就进行计算。
    

    输入要求：
    数字和运算符必须用空格间隔开。等号表示输入表达算结束，直达没有数据为止。
*/
#include<stack>
#include<stdlib.h>
#include<cstdlib>
#include<ctype.h>
#include<iostream>

using namespace std;

stack<double> s;
stack<char> c;
string str;
int i = 0;
double a, b, result;
/*
    计算后缀表达式
    使用全局的堆栈 stack<double> s, stack<char> c
*/
void evalPostFix() {
    switch(c.top()) {
        case '+':
            a = s.top(); s.pop();
            b = s.top(); s.pop();
            s.push(a + b);
        break;
        case '-':
            a = s.top(); s.pop();
            b = s.top(); s.pop();
            s.push(a - b);
        break;
        case '*':
            a = s.top(); s.pop();
            b = s.top(); s.pop();
            s.push(a * b);
        break;
        case '/':
            a = s.top(); s.pop();
            b = s.top(); s.pop();
            s.push(a / b);
        break;
    }
}
double inFixToPostFix() {
    while( cin >> str && str[0] != '=') {
        result = atof(str.c_str());
        if (result != 0.0) {
            s.push(result);
            //cout << result << " ";
        }
        else if(str == "0.0")
            s.push(result);
            else {
                //cout << str << endl;
                switch(str[0]) {
                    case ')' :
                        while(!c.empty() && c.top() != '(') {
                            evalPostFix();
                            c.pop();
                        }
                        c.pop();
                        break;
                    case '(' :
                        c.push(str[0]);
                        break;
                    case '-' :
                    case '+' :
                        while(!c.empty() && c.top() != '(') {
                            evalPostFix();
                            c.pop();
                        }
                        c.push(str[0]);
                        break;
                    case '*' :
                    case '/' :
                        while(!c.empty() && c.top() != '+' 
                                && c.top() != '-' && c.top() != '(') {
                            evalPostFix();
                            c.pop();
                        }
                        c.push(str[0]);
                        break;
                    default :
                        cout << "输入错误，重新运行" << endl;
                        exit(1);
                        break;
                }
            }
    }
    while(!c.empty()) {
        evalPostFix();
        c.pop();
    }
    double re;
    re = s.top();
    while(!s.empty()) {
        s.pop();
    }
    return re;
}

int main() {
    cout << "请输入中缀表达式，每个运算符，数字之间用空格隔开，=表式输入结束" << endl;
    while(i < 1000) {
        cout << inFixToPostFix() << endl;
        cout << "请输入中缀表达式，每个运算符，数字之间用空格隔开，=表式输入结束" << endl;
        i++;
    }
    return 0;
}

