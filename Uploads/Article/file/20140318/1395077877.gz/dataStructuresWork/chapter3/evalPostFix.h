#ifndef EVALPOST_H
#define EVALPOST_H
#include<stack>


double evalPostFix() {
    stack<double> s;
    string str;
    double a, b, result;
    cin >> str;
    while(cin >> str, str != '=') {
        result = strtod(str);
        if (result != 0.0)
            s.push(result);
        else if (str == "0.0")
            s.push(result);
            else
                switch(str) {
                    case '+':
                        a = s.top(); s.pop();
                        b = s.top; s.pop();
                        s.push(a + b);
                        break;
                    case '-':
                        a = s.top(); s.pop();
                        b = s.top; s.pop();
                        s.push(a - b);
                        break;
                    case '*':
                        a = s.top(); s.pop();
                        b = s.top; s.pop();
                        s.push(a * b);
                        break;
                    case '/':
                        a = s.top(); s.pop();
                        b = s.top; s.pop();
                        s.push(a / b);
                        break;
                }
    }
    return s.top();
}

#endif
