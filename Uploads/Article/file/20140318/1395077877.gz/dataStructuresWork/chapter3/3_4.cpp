
template <typename Object>
list<Object> intersection(const list<Object> & L1, 
                            const list<Object> & L2) {
    list<Object> intersect;
    typename list<Object>:: const_iterator itL1 = L1.begin();
    typename list<Object>:: const_iterator itL2 = L2.begin();
    while(ltL1 != L1.end() && itL2 != L2.end()) {
        if(*itL1 == *itL2) {
            intersect.push_back(*itL1);
            itL1++;
            itL2++;
        }else 
            if(*itL1 > *itL2) 
                itL2++;
            else
                itL1++;
        }
    }
    return intersect;
}
