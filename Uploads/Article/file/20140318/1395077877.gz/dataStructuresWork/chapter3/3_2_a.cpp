/*
    将单向链表相邻的元素交换
    @param Node * beforep 为要交换的元素的之前的一个元素
*/
void swapNext(Node * beforep) {
    Node *p, *afterp;
    p = beforep->next;
    afterp = p->next;
    p->next = afterp->next;
    betorep->next = afterp;
    afterp->next = p;
}
