
/*
    合并两个链表
*/
template <typename Object>
list<Object>listUnion(const list<Object> & L1, 
                            const list<Object> & L2) {
    list<Object> listU;
    typename list<Object>:: const_iterator itL1 = L1.begin();
    typename list<Object>:: const_iterator itL2 = L2.begin();
    while(ltL1 != L1.end() && itL2 != L2.end()) {
        if(*itL1 == *itL2) {
            if(*itL1 != listU.top())
                listU.push_back(*itL1);
            itL1++;
            itL2++;
        }else 
            if(*itL1 > *itL2) { 
                if(*itL2 != listU.top())
                    listU.push_back(*itL2);
                itL2++;
            }else{
                if(*itL1 != listU.top())
                    listU.push_back(*itL1);
                itL1++;
            }
        }
    }
    return listU;
}
