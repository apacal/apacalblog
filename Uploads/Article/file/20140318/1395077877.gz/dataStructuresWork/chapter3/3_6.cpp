#include <iostream>
#include <list>

using namespace std;

int main() {
    int n, m, i, j, mm, nn;
    list<int> mylist;
    list<int>::iterator it;
    cout<<"输入 N（人数）和 M（次数）"<< endl;
    cin >> n >> m;
    nn = n;
    mm = m % n;
    for(i = 1; i <= n; i++) {
        mylist.push_back(i);
    }
    it = mylist.begin();
    for(i = 0; i <n; i++) {
        mm = mm % nn;
        if (mm <= nn/2)
            for(j = 0; j < mm; j++) {
                it++;
                if(it == mylist.end()) {
                    it = mylist.begin();
                }
            }
        else
            for(j = 0; j < mm; j++) {
                if(it == mylist.begin())
                    it = --mylist.end();
                else
                    it--;
                }
        cout << *it << " ";
        it = mylist.erase(it);
        if(it == mylist.end())
            it = mylist.begin();
    }
    cout << endl;
    return 0;
}
