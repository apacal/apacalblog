#include<iostream>
#include<list>
#include<time.h>

using namespace std;
int printLots(list <int> L, list <int> P);

int main() {
    clock_t start, finish;
    int myL[] = {2, 33, 44, 55, 66};
    int myP[] = {1, 3, 4, 15, 17};
    list <int> L(myL, myL+5);
    list <int> P(myP, myP+5);

    start = clock();

    printLots(L, P);

    finish = clock();

    cout << "时间为：" << (finish - start)/1000 << "s" <<endl;
    return 0;
}

/*
    将list L 中的元素按照list P中元素作为下标输出
    @param list <int> L, list <int> P
    @author apacal
*/
int printLots(list <int> L, list <int> P) {
    int siz = L.size();
    list <int> ::const_iterator pIt;
    list <int> ::const_iterator lIt;
    int position = 0;
    for (pIt = P.begin(); pIt != P.end(); pIt++) {
        if(*pIt <= siz) {
            position = *pIt;
            cout << L[position] << endl;
        }else {
            break;
        }
    }
    return 0;
}
