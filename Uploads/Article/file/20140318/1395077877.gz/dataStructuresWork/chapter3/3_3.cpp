/*
 *  实现STL的find例程
 */
template <typename Iterator, typename Object>
Iterator find(Iterator start, Iterator end, const Obeject & x) {
    Iterator it = start;
    while(it != end && *it != x)
        it++;
    return it;
}
