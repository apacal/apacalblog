/*
    将双向链表的相邻元素交换
    @param Node * p 
*/
void swapNext(Node * p) {
    Node * beforep, * afterp;
    beforep = p->pre;
    afterp = p->next;
    beforep->next = afterp;
    p->next = afterp->next;
    p->next->pre = p;
    p->pre = afterp;
    afterp->pre = beforep;
    afterp->next = p;
}
