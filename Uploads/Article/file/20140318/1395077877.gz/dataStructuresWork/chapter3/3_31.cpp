template <typename Object>
struct Node {
    Node () {
        next = NULL;
    }
    Node(Object ob) : data(ob) {}
    Node(Object ob, Node * p) : data(ob), next(p) {}
    Object data;
    Node * next;
};

template <typename Object>
class stack {
    public: 
        stack() { head = NULL; }
        ~stack() { 
            while(head)
                pop();
        }

        void push(Object ob) {
            Node<Object> * p = new Node<Object>(ob, head);
            head = p;
        }

        Object top() {
            return (head->data);
        }

        void pop() {
            Node<Object> * p = head->next;
            delete head;
            head = p;
        }

    private:
        Node<Object> * head;
};
