#ifndef EVALPOST_H
#define EVALPOST_H
#include<stack>
#include<ctype.h>


double evalPostFix() {
    stack<double> s;
    string str;
    double a, b, result;
    while(cin >> str && str[0] != '=') {
        result = atof(str.c_str());
        if (result != 0.0) {
            s.push(result);
            cout << result << endl;
        }
        else if(str == "0.0")
            s.push(result);
            else
                switch(str[0]) {
                    case '+':
                        a = s.top(); s.pop();
                        b = s.top(); s.pop();
                        s.push(a + b);
                    break;
                    case '-':
                        a = s.top(); s.pop();
                        b = s.top(); s.pop();
                        s.push(a - b);
                    break;
                    case '*':
                        a = s.top(); s.pop();
                        b = s.top(); s.pop();
                        s.push(a * b);
                    break;
                    case '/':
                        a = s.top(); s.pop();
                        b = s.top(); s.pop();
                        s.push(a / b);
                    break;
                }
    }
    return s.top();
}

#endif
