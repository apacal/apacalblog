#include<iostream>
#include <cstdlib>

using namespace std;

#include "3_22.h"

int main() {
    cout << "11" << endl;
    cout << evalPostFix() << endl;
    return 0;
}
