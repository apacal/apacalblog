#!/bin/sh
# 发送电子邮件给王老师，把要传送的文件夹作为参数传入
# @param $1 附件文件夹

filename=$1
/bin/tar zcvf $filename.tar.gz $filename
dir=`pwd`
md5=`/usr/bin/md5sum $filename.tar.gz | /usr/bin/cut -d ' ' -f1`
name="20112200143ZhongQingzhu"
time=`date +%Y%m%d`
mv $filename.tar.gz $name$time-$md5.tar.gz
content="
王老师:
  作业

钟庆柱
$time
"
echo "$content" | /usr/local/mutt/bin/mutt -s "作业" prinse@126.com 1612577280@qq.com -a $dir/$name$time-$md5.tar.gz
rm -f $name$time-$md5.tar.gz
echo "send work mail successfully"
